import React, {Component} from 'react';
export class List extends Component {

    render() {
        return (
            <div className="panel panel-primary" >
                <div className="panel-heading">
                    <h3 className="panel-title"> {this.props.item.Title}</h3>                    
                </div>
                <div className="panel-body">
                    <div className="col-xs-12 col-md-12 col-sm-4">
                    <div className="row vertical-align">
                            
                        <div className="col-xs-1 col-md-2 col-sm-4">
                            <img className="imageClass" alt="fdsf" id={this.props.item.Id} onClick={this.props.showModal} src={this.props.item.ImageURLs.Thumb} />
                        </div>
                        <div className="col-xs-11  col-md-10 col-sm-4">
                                <strong>Desciption: </strong>
                                {this.props.item.Description}
                        </div>
                    </div>
                    </div>

                </div>
            </div>
        );
    }
}
