import React, {Component} from 'react';
import axios from 'axios';
import {ModalPopup} from './ModalPopup';
import {List} from './List'
export class Fruits extends Component{
  constructor(props){
    super(props);
    this.getAnimlasData();
    this.state={modalShow:false,
       shop:[]

   }
   this.setState({ modalShow: false });
   this.hideModal = this.hideModal.bind(this)
   this.showModal = this.showModal.bind(this)
}
citem;
getAnimlasData() {
   axios.get(`http://styleguide.effectivedigital.com/interview/api/animals`)
     .then(res => {
       const shop = res.data;
       this.setState({ shop });
     })
 }

showModal(event){
 // event.nativeEvent.target.selectedIndex;
 console.log(event.nativeEvent.target.id);

 console.log(this.state.shop[event.nativeEvent.target.id-1])
  this.setState({ modalShow: true ,cdata:this.state.shop[event.nativeEvent.target.id-1]});
}
hideModal(){
  this.setState({ modalShow: false });
   console.log(this.state.modalShow)
}

     getAnimlasData() {
        axios.get(`http://styleguide.effectivedigital.com/interview/api/fruitveg`)
          .then(res => {
            const shop = res.data;
            this.setState({ shop });
          })
      }
    
    
    
    render(){ 
          const items =  this.state.shop.map((item, key) =>
          <List item={item} key={item.id}  showModal={this.showModal}  />
          )
          return (
            <div>
            { this.state.modalShow ? 
              <ModalPopup cdata={this.state.cdata} hideModal={this.hideModal}/>
              : null }
            {items}
            </div>
          )
        //let modalPopupClose=()=> this.setState({modalShow:false});
    }
}