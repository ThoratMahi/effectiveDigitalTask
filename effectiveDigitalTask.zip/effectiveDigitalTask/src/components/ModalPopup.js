import React, {Component} from 'react';
import {Modal, Button, Row,Col, Form } from 'react-bootstrap';
export class ModalPopup extends Component{
constructor(props){
  super(props);
  console.log(props.cdata);
}
    
    render(){
        return(
               <div className='mask is-visible"'>
                  <div className='img-box'>
                    <h5>{this.props.cdata.Title}</h5>
                    <img src={this.props.cdata.ImageURLs.FullSize} width={this.props.cdata.ImageURLs.Width} height={this.props.cdata.ImageURLs.Height} />
                     <br/><br/> 
                      <div className="row">
                          <div className="col-md-3"><strong>Family: </strong>{this.props.cdata.Family}</div>
                         { this.props.cdata.CollectiveNoun ? <div className="col-md-6"><strong>CollectiveNoun: </strong> {this.props.cdata.CollectiveNoun}</div>:
                           <div className="col-md-6"><strong>Genus: </strong> {this.props.cdata.Genus}</div> 
                         }
                      </div>
                      
                      <a className="close" onClick={this.props.hideModal}>×</a>
                  </div>
                </div>
              );
            }
}