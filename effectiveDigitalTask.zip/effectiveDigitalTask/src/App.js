import React from 'react';
import './App.css';
import {Navigation} from './components/Navigation';
import {Animals} from './components/Animals';
import {Fruits} from './components/Fruits';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
// import {FruiMyVerticallyCenteredModalts} from './components/FruiMyVerticallyCenteredModalts';

function App() {
  return (
    // <Route path="/" component={Home} exact />
   <BrowserRouter>
    
      <div className='container'>
      {/* <FruiMyVerticallyCenteredModalts /> */}
      <Navigation /> 
        <Switch>
            <Route path="/animals" component={Animals} />
            <Route path="/fruits" component={Fruits} />
        </Switch>
      </div>
   </BrowserRouter>
   
   //<h1>Welcome</h1>
  );
}

export default App;
